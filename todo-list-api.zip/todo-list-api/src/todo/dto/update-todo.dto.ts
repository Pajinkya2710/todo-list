/* eslint-disable prettier/prettier */
export class UpdateTodoDto {
    title?: string;
    description?: string;
    status?: boolean;
  }
  